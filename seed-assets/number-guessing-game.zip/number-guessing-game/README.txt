Number guessing game
====================

Run it with:

    python game.py
